<html>
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </head>
    <body>
    <div class="container">
        
        <div><br>&nbsp</div>
        <div><br>&nbsp</div>
        <h1 class="text-center">Maturita z ČJ</h1>
    <div>
        <br>
          Český jazyk a literatura je zkušebním předmětem společné části maturitní zkoušky. Maturitní zkouška z českého jazyka a literatury je zkouškou komplexní. V návaznosti na vyhlášení zákona č. 135/2020 Sb. se zkouška pro žáky konající podle tohoto zákona skládá ze dvou dílčích zkoušek konaných formou didaktického testu a ústní zkoušky.
          Ostatní žáci (t.j. žáci konající podle pravidel školského zákona) konají tuto zkoušku podle standardních pravidel včetně písemné práce.
          </br>
          <br> didaktického testu </br>
               písemná práce (pouze pro žáky konající maturitní zkoušku podle školského zákona)
               <br>   ústní zkoušky </br>
          <br>
          Každou dílčí zkouškou jsou ověřovány především ty znalosti a dovednosti, k jejichž ověřování je příslušná forma dílčí zkoušky nejvhodnějším evaluačním (hodnotícím) nástrojem. Zároveň je tak minimalizováno nežádoucí překrývání působnosti jednotlivých dílčích zkoušek.
    </div>
        </div>
        <br>
        <img src="http://localhost/MatKnizkyUkol/picture/knihy.jpg" width="200" height="200" class="mx-auto d-block" alt="Knihy">
    </body>
</html>